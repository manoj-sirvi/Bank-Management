TEAM :- 
            **wwdob@DA**

Members :-
    1) Prince Singh Tomar   (2019101021)
    2) Shreyansh Verma      (2019113012)
    3) Manoj Sirvi          (2019111016)

working :- 
    1) Docker :- using port 5005 
        if don't have docker remove line *port=5005,* in while loop


**Instructions** :-
    1) import database using .sql file, Databse name = BANK, sql script stored in file  *BANK.sql*
    2) use python3 python.py to run the python script
    3) For  username : enter user which have permissions to alter the database and also that database.
            password : password of the user's account

**FUNCTIONS** :-
    1) options given along with what the do.
    2) Enter options number to use that function.
        like Enter choice> 1 (to enter the function at 1st point)
    3) Enter all data carefully and data must be reasonable otherwise error will occur.
        