import subprocess as sp
import pymysql
import pymysql.cursors

# delete employee :


def option2():
    try:
        id = input("Please enter ID of the employee : ")
        query = "select * from EMPLOYEE where ID = %s" % (id)
        val = cur.execute(query)
        result = cur.fetchall()
        x = 0
        for y in result:
            x = x + 1
        if (x == 0):
            print("Error : ID not present ")
            return
        query = "DELETE from DEPENDENT WHERE ID = %s"
        print(query, id)
        val = cur.execute(query, id)
        """ con.commit() """
        query = "DELETE from EMPLOYS WHERE employees_id = %s"
        print(query, id)
        val = cur.execute(query, id)
        """ con.commit() """
        query = "DELETE from ECONTACT WHERE ID = %s"
        print(query, id)
        val = cur.execute(query, id)
        """ con.commit() """
        query = "alter table EMPLOYS drop constraint EMPLOYS_ibfk_3"
        print(query)
        val = cur.execute(query)
        """ con.commit() """
        """ query = "alter table EMPLOYEE drop constraint EMPLOYEE_ibfk_1"
        print(query)
        val = cur.execute(query)
        con.commit()"""
        query = "alter table ECONTACT drop constraint ECONTACT_ibfk_1"
        print(query)
        val = cur.execute(query)
        """ con.commit() """
        query = "alter table DEPENDENT drop constraint DEPENDENT_ibfk_1"
        print(query)
        val = cur.execute(query)
        """ con.commit() """
        """ query = "alter table EMPLOYEE drop key EMPLOYEE_ibfk_1"
        print(query)
        val = cur.execute(query)
        con.commit() """
        query = "DELETE from EMPLOYEE WHERE ID = %s"
        print(query, id)
        val = cur.execute(query, id)
        """ con.commit() """
        """ query = "alter table EMPLOYEE add constraint EMPLOYEE_ibfk_1 foreign key (super_id) references EMPLOYEE(ID)"
        print(query)
        val = cur.execute(query)
        con.commit() """
        query = "alter table DEPENDENT add CONSTRAINT DEPENDENT_ibfk_1 FOREIGN KEY (ID) REFERENCES EMPLOYEE (ID)"
        print(query)
        val = cur.execute(query)
        """ con.commit() """
        query = "alter table EMPLOYS add CONSTRAINT EMPLOYS_ibfk_3 FOREIGN KEY (employees_id) REFERENCES EMPLOYEE (ID)"
        print(query)
        val = cur.execute(query)
        """ con.commit() """
        query = "alter table ECONTACT add constraint ECONTACT_ibfk_1 FOREIGN KEY (ID) REFERENCES EMPLOYEE (ID)"
        print(query)
        val = cur.execute(query)
        con.commit()

    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

    return

# delete ATM:


def option3():
    try:
        id = input("Enter ATM id :")
        query = "select * from ATM where atm_id = %s" % (id)
        val = cur.execute(query)
        result = cur.fetchall()
        x = 0
        for y in result:
            x = x + 1
        if (x == 0):
            print("Error : ID not present ")
            return
        query = "DELETE from HAS WHERE atm_id = %s"
        print(query, id)
        val = cur.execute(query, id)
        """ con.commit() """
        query = "alter table HAS drop constraint HAS_ibfk_3"
        print(query)
        val = cur.execute(query)
        """ con.commit() """
        query = "DELETE from ATM WHERE atm_id = %s"
        print(query, id)
        val = cur.execute(query, id)
        """ con.commit() """
        query = "alter table HAS add constraint HAS_ibfk_3 FOREIGN KEY (atm_id) REFERENCES ATM (atm_id)"
        print(query)
        val = cur.execute(query)
        con.commit()

    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

# Employee search


def option4():
    try:
        store = {}
        string = input("Enter the keyword : ")
        str_use = '%' + string + '%'
        command_string = "select * from EMPLOYEE where aadhar_no LIKE '"
        command_string = command_string + str(str_use) + "' OR ID LIKE '" + str(str_use) + "' OR FNAME LIKE '" + str(
            str_use) + "' OR MINIT LIKE '" + str(str_use) + "' OR LNAME LIKE '" + str(str_use)+"'"
        #query = "select * from EMPLOYEE where aadhar_no LIKE %s "
        cur.execute(command_string)
        result = cur.fetchall()
        # print("sdg")
        #for y in result:
        #    print(y)
        for x in result:
            # print("asd")
            eid = x["ID"]
            query = "select * FROM ECONTACT where ID = %s"
            cur.execute(query, eid)
            print(x)
            p = cur.fetchone()
            if p is not None:
                print("Contact No : ", p["contact_no"])
            else:
                print("Contact No : Not available")

    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

# customer search


def option5():
    try:
        store = {}
        string = input("Enter the keyword : ")
        str_use = '%' + string + '%'
        command_string = "select * from CUSTOMER where aadhar_no LIKE '"
        command_string = command_string + str(str_use) + "' OR ID LIKE '" + str(str_use) + "' OR fname LIKE '" + str(
            str_use) + "' OR lname LIKE '" + str(str_use) + "' OR mname LIKE '" + str(str_use) + "'"
        #query = "select * from EMPLOYEE where aadhar_no LIKE %s "
        cur.execute(command_string)
        result = cur.fetchall()

        for x in result:
            eid = x["ID"]
            query = "select * FROM cust_contact where cust_id = %s"
            cur.execute(query, eid)
            print(x)
            p = cur.fetchone()
            if p is not None:
                print("Contact No : ", p["contact_no"])
            else:
                print("Contact No : Not available")
            #print("Contact NO : ", p["contact_no"])
            query = "select * FROM OWNED_by where customer_no = %s"
            cur.execute(query, eid)
            p = cur.fetchone()
            if p is not None:
                print("Account No : ", p["account_no"])
            else:
                print("Account No : Not available")
            #print("Account NO : ", p["account_no"])

    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

# search customer by account Number :


def option6():
    try:
        store = {}
        string = input("Enter the keyword : ")
        str_use = '%' + string + '%'
        query = "select * from OWNED_by where account_no LIKE %s "
        cur.execute(query, str_use)
        result = cur.fetchall()
        for x in result:
            # print(x)
            eid = x["customer_no"]
            account_no = x["account_no"]
            query = "select * FROM CUSTOMER where ID = %s"
            cur.execute(query, eid)
            p = cur.fetchone()
            if p is not None:
                print(p)
                # print(cur.fetchone())
            query = "select * FROM cust_contact where cust_id = %s"
            cur.execute(query, eid)
            print("Account No : ", account_no)
            p = cur.fetchone()
            if p is not None:
                print("Contact No : ", p["contact_no"])
            else:
                print("Contact No : Not available")
            #print("Contact NO : ", p["contact_no"])

    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

# branch search :


def option7():
    try:
        store = {}
        string = input("Enter the keyword : ")
        str_use = '%' + string + '%'
        query = "select * from BRANCH where branch_code LIKE "
        query = query + "'" + str(str_use) + \
            "' OR name LIKE '" + str(str_use) + "'"
        cur.execute(query)
        result = cur.fetchall()
        for x in result:
            print(x)

    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

# select employee of a branch


def option8():
    try:
        store = {}
        string = input("Enter the Branch Name : ")
        str_use = '%' + string + '%'
        query = "select * from BRANCH where name LIKE %s "
        cur.execute(query, str_use)
        result = cur.fetchall()
        for x in result:
            branchcode = x["branch_code"]
            query = "select * from EMPLOYS where branch_id = %s "
            cur.execute(query, branchcode)
            a_result = cur.fetchall()
            print("Branch Code : ", branchcode)
            for y in a_result:
                employees_id = y["employees_id"]
                query = "select * from EMPLOYEE where ID = %s "
                cur.execute(query, employees_id)
                p = cur.fetchone()
                if p is not None:
                    print(p)

    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)


# branch LOAN
def option9():
    try:
        store = {}
        string = input("Enter the Branch Name : ")
        str_use = '%' + string + '%'
        query = "select * from BRANCH where name LIKE %s "
        cur.execute(query, str_use)
        result = cur.fetchall()
        for x in result:
            branchcode = x["branch_code"]
            query = "select * from ACCOUNT where branch_id = %s "
            cur.execute(query, branchcode)
            a_result = cur.fetchall()
            print("Branch Code : ", branchcode)
            for y in a_result:
                account_no = y["account_no"]
                query = "select * from LOAN where account_num = %s "
                cur.execute(query, account_no)
                b_result = cur.fetchall()
                for z in b_result:
                    print(z)

    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

# amount in  < & > account


def option10():
    try:
        print("Enter 1 for >")
        print("Enter 0 for <")
        lamda = input("Enter : ")
        string = "select * from ACCOUNT where amount "
        if(int(lamda) == 1):
            string = string + "> "
        else:
            string = string + "< "
        amount = input("Enter amount :")
        string = string + amount
        print(string)
        cur.execute(string)
        result = cur.fetchall()
        for x in result:
            # print(x)
            account_no = x["account_no"]
            amont = x["amount"]
            query = "select * from OWNED_by where account_no = %s "
            cur.execute(query, account_no)
            a_result = cur.fetchall()
            for y in a_result:
                customer_id = y["customer_no"]
                query = "select * from CUSTOMER where ID = %s"
                cur.execute(query, customer_id)
                b_result = cur.fetchall()
                for z in b_result:
                    print("fname : ", z["fname"])
                    print("mname : ", z["mname"])
                    print("lname : ", z["lname"])
                    print("account NO : ", account_no)
                    print("Amount : ", amont)
                    print(" ")
    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

# loan amount < & > thing


def option11():
    try:
        print("Enter 1 for >")
        print("Enter 0 for <")
        lamda = input("Enter : ")
        string = "select * from LOAN where amount "
        if(int(lamda) == 1):
            string = string + "> "
        elif(int(lamda) == 0):
            string = string + "< "
        else:
            print("ERROR")
            return
        amount = input("Enter amount :")
        string = string + amount
        print(string)
        cur.execute(string)
        result = cur.fetchall()
        for x in result:
            # print(x)
            customer_id = x["customer_id"]
            loan_id = x["account_num"]
            amont = x["amount"]
            query = "select * from CUSTOMER where ID = %s "
            cur.execute(query, customer_id)
            a_result = cur.fetchall()
            for z in a_result:
                print("fname : ", z["fname"])
                print("mname : ", z["mname"])
                print("lname : ", z["lname"])
                print("Loan id : ", loan_id)
                print("Amount : ", amont)
                print(" ")
    except Exception as e:
        con.rollback()
        #print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

# add customer function :


def option12():
    try:
        print("Enter new customer's details: ")
        print("ALL integer should less than 32 bits")
        row = {}
        row["id"] = int(input("ID (integer): "))
        row["aadhar_no"] = int(input("Aadhar_no (integer): "))
        row["DOB"] = input("DOB (YYYY-MM-DD): ")
        name = {}
        print(
            "enter your name in (fname , mname, lname ) or in (fname,lname) form or in (fname) form")
        name = input("name (no more then 30 character each of them): ").split()
        if(len(name) == 2):
            row["Fname"] = name[0]
            row["Minit"] = ""
            row["Lname"] = name[1]

        else:
            if(len(name) == 3):
                row["Fname"] = name[0]
                row["Minit"] = name[1]
                row["Lname"] = name[2]
            else:
                if(len(name) == 1):
                    row["Fname"] = name[0]
                    row["Minit"] = ""
                    row["Lname"] = ""
                else:
                    print(
                        "enter your name in (fname , mname, lname ) or in (fname,lname) form or in (fname) form")

        address = {}
        address = input(
            "Address (locality state country pincode not max then 50 character): ").split()
        row["pan_no"] = int(input("pan_no (integer): "))
        row["account_no"] = int(input("account_no (integer): "))
        row["branch_id"] = int(input("branch_id (integer): "))
        row["amount"] = int(input("amount (integer): "))
        row["date"] = input("date_of_creation (YYYY-MM-DD): ")
        row["account_type"] = input(
            "account_type (kids_account,saving_account,current_account,NRI_account): ")
        row["cards"] = input("card_type (Debit_card or Credit_card): ")
        row["valid_through"] = input("valid_through (YYYY-MM-DD): ")
        row["card_no"] = int(input("card_no (integer): "))
        row["pin"] = int(input("pin (integer): "))
        row["cheque_id"] = int(input("cheque_id (integer): "))
        row["upi_id"] = int(input("upi_id (integer): "))
        print("Please enter your contact no of 10 digit")
        row["contact_no"] = (input("contact_no: "))
        if(len(row["contact_no"]) != 10):
            # checking constriant for contact number
            print("You don't enter valid numer")
        row["contact_no"] = int(row["contact_no"])
        mycursor = con.cursor()
        mycursor.execute("SELECT branch_code FROM BRANCH")
        myresult = mycursor.fetchall()
        f = 0
        for x in myresult:
            k = list(x)
            if(x[k[0]] == row["branch_id"]):
                f = 1
        if(f == 0):
            print("GIVEN BRANCH ID DOESN'T EXIST")
            return
        query = "INSERT INTO CUSTOMER (ID,aadhar_no,DOB,fname,mname,lname,address_line1,address_line2,address_line3,address_line4,pan_no) VALUES('%d','%d','%s','%s','%s','%s','%s','%s','%s','%s','%d')" % (
            row["id"], row["aadhar_no"], row["DOB"], row["Fname"], row["Minit"], row[
                "Lname"], address[0], address[1], address[2], address[3], row["pan_no"]
        )
        cur.execute(query)
       # con.commit()
        query1 = "INSERT INTO ACCOUNT (account_no,branch_id,amount,date_of_creation,account_type)VALUES('%d','%d','%d','%s','%s')" % (
            row["account_no"], row["branch_id"], row["amount"], row["date"], row["account_type"]
        )
        cur.execute(query1)
       # con.commit()
        query2 = "INSERT INTO `OWNED_by`(account_no,customer_no)VALUES('%d','%d')" % (
            row["account_no"], row["id"]
        )
        cur.execute(query2)
        con.commit()
        query3 = "INSERT INTO CARDS(card_no,valid_through,pin)vALUES('%d','%s','%d')" % (
            row["card_no"], row["valid_through"], row["pin"]
        )
        cur.execute(query3)
       # con.commit()
        if(row["cards"] == "Debit_card"):
            query4 = "INSERT INTO DEBIT_CARD(card_val)VALUES('%d')" % (
                row["card_no"]
            )
            cur.execute(query4)
            # con.commit()
        else:
            query4 = "INSERT INTO CREDIT_CARD(card_val)VALUES('%d')" % (
                row["card_no"]
            )
            cur.execute(query4)
            # con.commit()
        query5 = "INSERT INTO cheque(cheque_id)VALUES('%d')" % (
            row["cheque_id"]
        )
        cur.execute(query5)
       # con.commit()
        query6 = "INSERT INTO UPI(upi_id)VALUES('%d')" % (
            row["upi_id"]
        )
        cur.execute(query6)
       # con.commit()
        query7 = "INSERT INTO `GOT`(customer_id,cards_id,cheque_id,upi_id)VALUES('%d','%d','%d','%d')" % (
            row["id"], row["card_no"], row["cheque_id"], row["upi_id"]
        )
        cur.execute(query7)
        query8 = "INSERT INTO cust_contact(cust_id,contact_no) VALUES ('%d','%d')" % (
            row["id"], row["contact_no"]
        )
        cur.execute(query8)
        con.commit()
        print("DATA INSERTED SUCCESSFULLY")
    except Exception as e:
        con.rollback()
        print("failed to insert data")
        print(">>>>>>>> ", e)


# aggregate find cash in account :
def option13():
    try:
        account_no = int(input("Account_no: "))
        # print("manoj")
        mycursor = con.cursor()
        # print("rahul")
        mycursor.execute("SELECT account_no,amount FROM ACCOUNT")
        myresult = mycursor.fetchall()
       # print("hello")
        sum = 0
        f = 0
        for x in myresult:
            k = list(x)
           # print(x[k[1]], x[k[0]])
            if(x[k[0]] == account_no):
                sum += x[k[1]]
                f = 1
                break
        if(f == 0):
            print("Account_no doesn't exist")
            return
        mycursor.execute("SELECT account_no,amount FROM payment")
        myresult1 = mycursor.fetchall()
        for x in myresult1:
            k = list(x)
            if(x[k[0]] == account_no):
                sum -= x[k[1]]
        mycursor.execute("SELECT account_no,amount FROM `Transaction`")
        myresult1 = mycursor.fetchall()
        for x in myresult1:
            k = list(x)
            if(x[k[0]] == account_no):
                sum -= x[k[1]]
        print("Current balance is", sum)

    except Exception as e:
        con.rollback()
        print("Failed to claculate amount")
        print(">>>>>>>", e)

# total cash in bank :


def option14():
    try:
        bank_id = int(input("Enter bank id: "))
        mycursor = con.cursor()
        sum = 0
        f = 0
        mycursor.execute("SELECT ID FROM Bank")
        tree = mycursor.fetchall()
        for x in tree:
            k = list(x)
            if(x[k[0]] == bank_id):
                f = 1
        if(f == 0):
            print("NO BANK EXIST WITH GIVEN ID")
            return

        mycursor.execute("SELECT bank_id,branch_id FROM EMPLOYS")
        myresult = mycursor.fetchall()
        lis = []
        for x in myresult:
            k = list(x)
            if(x[k[0]] == bank_id):
                lis.append(x[k[1]])
        mycursor.execute("SELECT branch_id,amount FROM ACCOUNT")
        result = mycursor.fetchall()
        for a in result:
            for x in lis:
                k = list(a)
                if(a[k[0]] == x):
                    sum += a[k[1]]
                    break
        print("Total amount in bank: ", sum)

    except Exception as e:
        con.rollback()
        print("Failed to claculate amount")
        print(">>>>>>>", e)


# employees who account in the bank :
def option15():
    try:
        a = []
        mycursor = con.cursor()
        mycursor.execute("SELECT * FROM EMPLOYEE")
        result = mycursor.fetchall()
        mycursor.execute("SELECT bank_id,employees_id FROM EMPLOYS")
        res = mycursor.fetchall()
        for x in result:
            k = list(x)
            for y in res:
                t = list(y)
                if(x[k[4]] == y[t[1]]):
                    a.append((x[k[8]], y[t[0]]))
       # print(a)
        mycursor.execute("SELECT x.aadhar_no,EMPLOYS.bank_id FROM (SELECT ACCOUNT.branch_id,p.aadhar_no FROM (SELECT CUSTOMER.aadhar_no,OWNED_by.account_no FROM CUSTOMER INNER JOIN OWNED_by ON CUSTOMER.ID=OWNED_by.customer_no) as p INNER JOIN ACCOUNT ON ACCOUNT.account_no=p.account_no) as x INNER JOIN EMPLOYS ON EMPLOYS.branch_id=x.branch_id")
        hy = mycursor.fetchall()
        # print(hy)
        b = []
        ans = []
        for x in hy:
            k = list(x)
            for y in a:
                if(y[0] == x[k[0]] and y[1] == x[k[1]]):
                    ans.append(y[0])
        ans = list(dict.fromkeys(ans))

       # print("hii")
        print(ans)
        if(len(ans) == 0):
            print("None of employee and customer belong to same bank")
        else:
            for x in ans:
                for y in result:
                    k = list(y)
                    # print(y[k[5]])
                    if(x == y[k[8]]):
                        if(y[k[1]] != None):
                            print("Name: ", y[k[1]], end=" ")
                        if(y[k[2]] != None):
                            print(y[k[2]], end=" ")
                        if(y[k[3]] != None):
                            print(y[k[3]], end="\n")
                        print("aadhar_no: ", x)
                        print("salary: ", y[k[7]])
                        print("\n")

    except Exception as e:
        # con.rollback()
        print("failed to process")
        print(">>>>>>>>", e)


# who didn't payed their loan
def option16():
    try:
        mycursor = con.cursor()
        mycursor.execute("SELECT customer_id,account_num FROM LOAN")
        myresult = mycursor.fetchall()
        mycursor.execute("SELECT * FROM CUSTOMER")
        detial = mycursor.fetchall()
        for x in myresult:
            k = list(x)
            print("Cutomer_id:", x[k[0]])
            print("Account_nu:", x[k[1]])
            for y in detial:
                k1 = list(y)
                if(y[k1[0]] == x[k[0]]):
                    print("Aadhar_no:", y[k1[1]])
                    print("DOB:", y[k1[2]])
                    if(y[k1[3]] != None):
                        print("Name:", y[k1[3]], end=" ")
                    if(y[k1[4]] != None):
                        print(y[k1[4]], end=" ")
                    if(y[k1[5]] != None):
                        print(y[k1[5]], end="\n")
                    print("pan_no:", y[k1[10]])
                    print(end="\n")
    except Exception as e:
        con.rollback()
        print("Failed to retrieve data")
        print(">>>>>>>>", e)


# update employee :
def option17():
    try:
        print('Enter details of the employee to be updated')
        idnet = input("Enter employee ID ")
        idnet = int(idnet)
        query = "select * from EMPLOYEE where ID = %d" % (idnet)
        val = cur.execute(query)
        result = cur.fetchall()
        x = 0
        for y in result:
            x = x + 1
        if (x == 0):
            print("ID not found")
            return

        roe = ['ID', 'FNAME', 'MINIT', 'LNAME', 'Super_id', 'DOB', 'post', 'salary', 'aadhar_no',
               'address_line1', 'address_line2', 'address_line3', 'address_line4', 'contact']
        print("Attribute : FNAME,MINIT,LNAME,Super_id,DOB,post,salary,aadhar_no,address_line1,address_line2,address_line3,address_line4,contact")
        var = (input("Write Attributes that needs to be updated(separated by space) use contact when changing contact no. ")).split(' ')
        for i in range(len(var)):
            print(var[i])
        for i in range(len(var)):
            for j in range(len(roe)):
                if var[i] == roe[j]:
                    if var[i] == 'ID':
                        print("ID can't be changed")
                        continue
                    print("Insert %s value" % (var[i]))
                    if var[i] == 'Super_id':
                        cur.execute(
                            "SELECT * from EMPLOYS where EMPLOYS.branch_id=(SELECT branch_id from EMPLOYS where employees_id=%d )" % idnet)
                        res = cur.fetchall()
                        print("Select one of the ginve ID's")
                        print(res)
                    if (var[i] == 'post'):
                        print('Please enter cashier or supervisor')
                    elif (var[i] == 'DOB'):
                        print('Enter in YYYY-MM-DD format')
                    elif (var[i] == 'contact'):
                        print('Enter a valid 10 digit number')
                    ans = input()
                    if var[i] == 'ID' or var[i] == 'Super_id' or var[i] == 'salary' or var[i] == 'aadhar_no' or var[i] == 'contact':
                        ans = int(ans)
                        if var[i] == 'contact':
                            if(len(str(ans)) != 10):
                                print("Please enter a valid contact Number")
                                return
                            sq1 = "update ECONTACT set contact_no = %d where ID = %d" % (
                                ans, idnet)
                        else:
                            sq1 = "update EMPLOYEE set %s=%d WHERE ID = %d" % (
                                var[i], ans, idnet)
                    else:
                        sq1 = "update EMPLOYEE set %s='%s' WHERE ID = %d" % (
                            var[i], ans, idnet)

                    print(sq1)
                    cur.execute(sq1)
                    con.commit()
    except Exception as e:
        con.rollback()
        print('failed to update into database')
        print('>>>>>', e)


# update customer :
def option18():
    try:
        print('Enter details of the Customer to be updated')
        idnet = input("Enter Customer ID ")
        idnet = int(idnet)
        query = "select * from CUSTOMER where ID = %d" % (idnet)
        val = cur.execute(query)
        result = cur.fetchall()
        x = 0
        for y in result:
            x = x + 1
        if (x == 0):
            print("ID not found")
            return

        roe = ['ID', 'fname', 'mname', 'lname', 'pan_no', 'DOB', 'salary', 'aadhar_no',
               'address_line1', 'address_line2', 'address_line3', 'address_line4', 'branch_id', 'contact']
        print("Attributes : fname,mname,lname,pan_no,DOB,salary,aadhar_no,address_line1,address_line2,address_line3,address_line4,branch_id,contact")
        var = (input("Write Attributes that needs to be updated(separated by space) use branch_id if changing branch ,use contact when changing contact no. ")).split(' ')
        for i in range(len(var)):
            print(var[i])
        for i in range(len(var)):
            for j in range(len(roe)):
                if var[i] == roe[j]:
                    print("Insert %s value" % (var[i]))
                    if (var[i] == 'ID'):
                        print("ID CAN'T BE CHANGED")
                        continue
                    if (var[i] == 'DOB'):
                        print('Enter in YYYY-MM-DD format')
                    if (var[i] == 'contact'):
                        print('ENTER 10 digit contact no')
                    if (var[i] == 'branch_id'):
                        cur.execute("SELECT branch_code from BRANCH")
                        result = cur.fetchall()
                        print(
                            'SELECT ANY ONE OF THE BRANCH_ID YOU WISH TO BE TRANSFERRED TO')
                        print(result)
                    ans = input()
                    if var[i] == 'ID' or var[i] == 'aadhar_no' or var[i] == 'branch_id' or var[i] == 'contact':
                        ans = int(ans)
                        if var[i] == 'contact':
                            if(len(str(ans)) != 10):
                                print("Please enter a valid contact Number")
                                return
                            sq1 = "update cust_contact set contact_no = %d where cust_id = %d" % (
                                ans, idnet)
                            # print(sq1)
                        elif var[i] == 'branch_id':
                            cur.execute(
                                "SELECT account_no FROM OWNED_by WHERE customer_no = %d" % idnet)
                            res = cur.fetchall()
                            print("below")
                            for t in res:
                                p = list(t)
                                vari = t[p[0]]
                            vari = int(vari)
                            sq1 = "update ACCOUNT set branch_id=%d where account_no=%d" % (
                                ans, vari)
                            # print(sq1)
                        else:
                            sq1 = "update CUSTOMER set %s='%d' WHERE ID = %d" % (
                                var[i], ans, idnet)
                    else:
                        sq1 = "update CUSTOMER set %s='%s' WHERE ID = %d" % (
                            var[i], ans, idnet)

                    print(sq1)
                    cur.execute(sq1)
                    con.commit()
    except Exception as e:
        con.rollback()
        print('failed to update into database')
        print('>>>>>', e)


def hireAnEmployee():
    """
    This is a sample function implemented for the refrence.
    This example is related to the Employee Database.
    In addition to taking input, you are required to handle domain errors as well
    For example: the SSN should be only 9 characters long
    Sex should be only M or F
    If you choose to take Super_SSN, you need to make sure the foreign key constraint is satisfied
    HINT: Instead of handling all these errors yourself, you can make use of except clause to print the error returned to you by MySQL
    """
    try:
        # Takes emplyee details as input
        row = {}
        print("Enter new employee's details: ")
        print("all integer should be less then 32 bits")
        row["id"] = int(input("ID (integer): "))
        name = {}

        print(
            "enter your name in (fname , mname, lname ) or in (fname,lname) form or in (fname) form")
        name = input("name: ").split()
        if(len(name) == 2):
            row["Fname"] = name[0]
            row["Minit"] = ""
            row["Lname"] = name[1]

        else:
            if(len(name) == 3):
                row["Fname"] = name[0]
                row["Minit"] = name[1]
                row["Lname"] = name[2]
            else:
                if(len(name) == 1):
                    row["Fname"] = name[0]
                    row["Minit"] = ""
                    row["Lname"] = ""
                else:
                    print(
                        "enter your name in (fname , mname, lname ) or in (fname,lname) form or in (fname) form")

        row["Super_id"] = int(input("Super_id (integer): "))
        row["DOB"] = input("Birth Date (YYYY-MM-DD): ")
        row["post"] = input("post (supervisor or cashier) ")
        row["Salary"] = int((input("Salary (integer): ")))
        row["aadhar_no"] = int(input("aadhar_no (integer): "))
        address = {}
        address = input(
            "address(locality state country pincode and each is less then 50 cahracter) ").split()
        row["locality"] = str(address[0])
        row["state"] = str(address[1])
        row["country"] = str(address[2])
        row["pincode"] = str(address[3])
        print("please enter your 10 digit contact Number")
        row["contact_no"] = (input("contact_no (integer): "))
        if(len(row["contact_no"]) != 10):
            print("Please enter a valid contact Number")
            return                                       # checking constriant for contact number
        row["contact_no"] = int(row["contact_no"])
        row["bank_id"] = int(input("bank_id (integer): "))
        row["branch_id"] = int(input("branch_id (integer): "))
        depe = {}
        depe = input(
            "dependent (Fname , Mname , Lname of dependent): ")
        print(row["locality"])

       # row["Dno"] = int(input("Dno: "))

        mycursor = con.cursor()
        # print("hii1\n")
        mycursor.execute("SELECT employees_id FROM EMPLOYS")

      #  print("hii2\n")
        myresult = mycursor.fetchall()
        # print(myresult)
        """
        mycursor.execute("SELECT * FROM EMPLOYEE")
        employee = mycursor.fetchall()
        print(employee)
        mycursor.execute("SELECT * FROM `DEPENDENT`")
        depend = mycursor.fetchall()
        print(depend)"""
     #   mycursor.execute("DESC EMPLOYEE")
      #  a = mycursor.fetchall()
        # print(len(myresult))
        # print(myresult)
       # print("tree")
        # list= [(k,v) for k,v in myresult.item()]
        mycursor = con.cursor()
       # print("hii1\n")
        f = 0
        h = 0
        mycursor.execute("SELECT employees_id,branch_id,bank_id FROM EMPLOYS")
        result = mycursor.fetchall()
        for x in result:
            k = list(x)
            if(x[k[1]] == row["branch_id"]):
                f = 1
            if(x[k[2]] == row["bank_id"]):
                h = 1
        # print(f)
        if(f == 1):
            if(row["post"] == "cashier"):
                query = "INSERT INTO EMPLOYEE(ID,FNAME,MINIT,LNAME,Super_id,DOB,post,salary,aadhar_no,address_line1,address_line2,address_line3,address_line4) VALUES('%d', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s')" % (
                    row["id"], row["Fname"], row["Minit"], row["Lname"], row["Super_id"], row["DOB"], row["post"], row["Salary"], row["aadhar_no"], row["locality"], row["state"], row["country"], row["pincode"])
                cur.execute(query)
                query1 = "INSERT INTO EMPLOYS(bank_id,branch_id,employees_id) VALUES('%d','%d','%d')" % (
                    row["bank_id"], row["branch_id"], row["id"])
                cur.execute(query1)
                query4 = "INSERT INTO `DEPENDENT`(ID,dependent_fname,dependent_mname,dependent_lname) VALUES ('%d','%s','%s','%s')" % (
                    row["id"], depe[0], depe[1], depe[2]
                )
                cur.execute(query4)
                query8 = "INSERT INTO ECONTACT(ID,contact_no) VALUES ('%d','%d')" % (
                    row["id"], row["contact_no"]
                )
                cur.execute(query8)
                con.commit()
                print("data inserted successfully")
            else:
                print("you enter invalid data Please check data")
        else:
            if(row["post"] == "supervisor"):
                if(h == 0):
                    print("Please enter bank detail")
                    naam = input("bank_name: ")
                    address1 = {}
                    address1 = input(
                        "address(locality state country pincode) ").split()
                    query2 = "INSERT INTO Bank(ID,`name`,head_quater_address_line1,head_quater_address_line2,head_quater_address_line3,head_quater_address_line4) VALUES('%d','%s','%s','%s','%s','%s')" % (
                        row["bank_id"], naam, address[0], address[1], address[2], address[3]
                    )
                    cur.execute(query2)
                if(f == 0):
                    print("please enter branch detail:")
                    name = input("branch_name: ")
                    address2 = {}
                    address2 = input(
                        "address(locality state country pincode) ").split()
                    query3 = "INSERT INTO BRANCH(branch_code,`name`,address_line1,address_line2,address_line3,address_line4) VALUES ('%d','%s','%s','%s','%s','%s')" % (
                        row["branch_id"], name, address2[0], address2[1], address2[2], address2[3]
                    )
                    cur.execute(query3)
                query = "INSERT INTO EMPLOYEE(ID,FNAME,MINIT,LNAME,Super_id,DOB,post,salary,aadhar_no,address_line1,address_line2,address_line3,address_line4) VALUES('%d', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s')" % (
                        row["id"], row["Fname"], row["Minit"], row["Lname"], row["Super_id"], row["DOB"], row["post"], row["Salary"], row["aadhar_no"], row["locality"], row["state"], row["country"], row["pincode"])
                cur.execute(query)
                query1 = "INSERT INTO EMPLOYS(bank_id,branch_id,employees_id) VALUES('%d','%d','%d')" % (
                    row["bank_id"], row["branch_id"], row["id"])
                cur.execute(query1)
                query5 = "INSERT INTO `ECONTACT`(ID,contact_no) VALUES ('%d','%d')" % (
                    row["id"], row["contact_no"]
                )
                cur.execute(query5)
                print(query5)
                query4 = "INSERT INTO `DEPENDENT`(ID,dependent_fname,dependent_mname,dependent_lname) VALUES ('%d','%s','%s','%s')" % (
                    row["id"], depe[0], depe[1], depe[2]
                )
                cur.execute(query4)
                """ query8 = "INSERT INTO ECONTACT(ID,contact_no) VALUES ('%d','%d')" % (
                    row["id"], row["contact_no"]
                )
                cur.execute(query8) """
                con.commit()
                print("DATA INSERTED SUCCESSFULLY")
            else:
                print("you can't insert new employee without inserting supervisor")
                # con.commit()

    except Exception as e:
        con.rollback()
        print("Failed to insert into database")
        print(">>>>>>>>>>>>>", e)

    return


def dispatch(ch):
    """
    Function that maps helper functions to option entered
    """

    if(ch == 1):
        hireAnEmployee()
    elif(ch == 2):
        option2()
    elif(ch == 3):
        option3()
    elif(ch == 4):
        option4()
    elif(ch == 5):
        option5()
    elif(ch == 6):
        option6()
    elif(ch == 7):
        option7()
    elif(ch == 8):
        option8()
    elif(ch == 9):
        option9()
    elif(ch == 10):
        option10()
    elif(ch == 11):
        option11()
    elif(ch == 12):
        option12()
    elif(ch == 13):
        option13()
    elif(ch == 14):
        option14()
    elif(ch == 15):
        option15()
    elif(ch == 16):
        option16()
    elif(ch == 17):
        option17()
    elif(ch == 18):
        option18()
    elif(ch == 19):
        option19()
    elif(ch == 20):
        option20()
    else:
        print("Error: Invalid Option")


# Global
while(1):
    tmp = sp.call('clear', shell=True)

    # Can be skipped if you want to hard core username and password
    username = input("Username: ")
    password = input("Password: ")

    try:
        # Set db name accordingly which have been create by you
        # Set host to the server's address if you don't want to use local SQL server
        con = pymysql.connect(host='localhost',
                              user=username,
                              password=password,
                              db='BANK',
                              #port=5005,
                              cursorclass=pymysql.cursors.DictCursor)
        tmp = sp.call('clear', shell=True)

        if(con.open):
            print("Connected")
        else:
            print("Failed to connect")

        tmp = input("Enter any key to CONTINUE>")

        with con.cursor() as cur:
            while(1):
                tmp = sp.call('clear', shell=True)
                # Here taking example of Employee Mini-world
                print("1. Option 1 - Insert an Employee")  # Hire an Employee
                print("2. Option 2 - Delete an Employee")  # Fire an Employee
                print("3. Option 3 - Delete an ATM")  # Promote Employee
                print("4. Option 4 - Employee Search")  # Employee Statistics
                print("5. Option 5 - Customer Search")
                print(
                    "6. Option 6 - Search customer by account Number(partial account number matching enabled)")
                print(
                    "7. Option 7 - Branch Search (partal name or code matching enabled")
                print("8. Option 8 - Select Employee working in a Branch")
                print("9. Option 9 - List Loan given by a Branch")
                print(
                    "10. Option 10 - list accounts with amount < OR > some_amount in them")
                print(
                    "11. Option 11 - list loans with amount < OR > some_amount in them")
                print("12. Option 12 - Insert Customer")
                print("13. Option 13 - Cash in an account after Transactions / payments")
                print("14. Option 14 - Total Amount stored by Bank")
                print("15. Option 15 - Employee who have account in bank")
                print("16. Option 16 - People who didn't pay their Loan")
                print("17. Option 17 - Update Employee")
                print("18. Option 18 - Update Customer")
                print("19. Logout")
                ch = int(input("Enter choice> "))
                tmp = sp.call('clear', shell=True)
                if ch == 19:
                    break
                else:
                    dispatch(ch)
                    tmp = input("Enter any key to CONTINUE>")

    except:
        tmp = sp.call('clear', shell=True)
        print("Connection Refused: Either username or password is incorrect or user doesn't have access to database")
        tmp = input("Enter any key to CONTINUE>")
