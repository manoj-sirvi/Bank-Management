-- MySQL dump 10.13  Distrib 8.0.21, for Linux (x86_64)
--
-- Host: localhost    Database: BANK
-- ------------------------------------------------------
-- Server version	8.0.21-0ubuntu0.20.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ACCOUNT`
--
DROP DATABASE IF EXISTS `BANK`;

CREATE DATABASE `BANK`;

USE BANK;

DROP TABLE IF EXISTS `ACCOUNT`; 

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ACCOUNT` (
        `account_no` bigint NOT NULL,
  `branch_id` bigint  NOT NULL,
  `amount` bigint  DEFAULT NULL,
  `date_of_creation` date NOT NULL,
  `account_type` enum('kids_account','saving_account','current_account','NRI_account') NOT NULL,
  PRIMARY KEY (`account_no`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `ACCOUNT_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `BRANCH` (`branch_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ACCOUNT`
--

LOCK TABLES `ACCOUNT` WRITE;
/*!40000 ALTER TABLE `ACCOUNT` DISABLE KEYS */;
INSERT INTO `ACCOUNT` VALUES (110112,113498,100000,'2015-01-01','saving_account'),(112211,113498,500000,'2014-01-01','current_account'),(112233,113498,300000,'2016-01-01','NRI_account'),(341792,421392,200000,'2017-01-01','current_account'),(491378,421392,100000,'2018-01-01','saving_account');
/*!40000 ALTER TABLE `ACCOUNT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ATM`
--

DROP TABLE IF EXISTS `ATM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ATM` (
  `atm_id` bigint  NOT NULL,
  `amount_of_cash` bigint  DEFAULT NULL,
  `Location_line1` varchar(30) NOT NULL,
  `Location_line2` varchar(30) NOT NULL,
  `Location_line3` varchar(30) NOT NULL,
  `Location_line4` varchar(30) NOT NULL,
  `refill_date` date NOT NULL,
  PRIMARY KEY (`atm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ATM`
--

LOCK TABLES `ATM` WRITE;
/*!40000 ALTER TABLE `ATM` DISABLE KEYS */;
INSERT INTO `ATM` VALUES (11213,10000,'ij','kl','mn','op','2020-01-01'),(11321,10000,'yz','ba','dc','fe','2020-01-01'),(42123,10000,'ab','cd','ef','gh','2020-01-01'),(42213,10000,'qr','st','uv','wx','2020-01-01');
/*!40000 ALTER TABLE `ATM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BORROW`
--

DROP TABLE IF EXISTS `BORROW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BORROW` (
  `loan_id` bigint  NOT NULL,
  `customer_id` bigint  NOT NULL,
  PRIMARY KEY (`loan_id`,`customer_id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  CONSTRAINT `BORROW_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `CUSTOMER` (`ID`),
  CONSTRAINT `BORROW_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `LOAN` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BORROW`
--

LOCK TABLES `BORROW` WRITE;
/*!40000 ALTER TABLE `BORROW` DISABLE KEYS */;
INSERT INTO `BORROW` VALUES (491378,101),(341792,103),(112233,104);
/*!40000 ALTER TABLE `BORROW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BRANCH`
--

DROP TABLE IF EXISTS `BRANCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BRANCH` (
  `branch_code` bigint  NOT NULL,
  `name` varchar(20) NOT NULL,
  `address_line1` varchar(50) NOT NULL,
  `address_line2` varchar(50) NOT NULL,
  `address_line3` varchar(50) NOT NULL,
  `address_line4` varchar(50) NOT NULL,
  PRIMARY KEY (`branch_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BRANCH`
--

LOCK TABLES `BRANCH` WRITE;
/*!40000 ALTER TABLE `BRANCH` DISABLE KEYS */;
INSERT INTO `BRANCH` VALUES (113498,'khapoli','khapoli','maharashtra','india','401106'),(421392,'panvel','panvel','maharashtra','india','402106');
/*!40000 ALTER TABLE `BRANCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Bank`
--

DROP TABLE IF EXISTS `Bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Bank` (
  `ID` bigint  NOT NULL,
  `name` varchar(20) NOT NULL,
  `head_quater_address_line1` varchar(50) DEFAULT NULL,
  `head_quater_address_line2` varchar(50) DEFAULT NULL,
  `head_quater_address_line3` varchar(50) DEFAULT NULL,
  `head_quater_address_line4` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bank`
--

LOCK TABLES `Bank` WRITE;
/*!40000 ALTER TABLE `Bank` DISABLE KEYS */;
INSERT INTO `Bank` VALUES (11,'UNION','l','m','n','k'),(42,'SBI','x','y','z','p');
/*!40000 ALTER TABLE `Bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Business_banking`
--

DROP TABLE IF EXISTS `Business_banking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Business_banking` (
  `ID` bigint  NOT NULL,
  `customer_account_no` bigint  NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `customer_account_no` (`customer_account_no`),
  CONSTRAINT `Business_banking_ibfk_1` FOREIGN KEY (`customer_account_no`) REFERENCES `ACCOUNT` (`account_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Business_banking`
--

LOCK TABLES `Business_banking` WRITE;
/*!40000 ALTER TABLE `Business_banking` DISABLE KEYS */;
INSERT INTO `Business_banking` VALUES (34,112233),(8,341792),(1,491378);
/*!40000 ALTER TABLE `Business_banking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CARDS`
--

DROP TABLE IF EXISTS `CARDS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CARDS` (
  `card_no` bigint  NOT NULL,
  `valid_through` date NOT NULL,
  `pin` bigint  NOT NULL,
  PRIMARY KEY (`card_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CARDS`
--

LOCK TABLES `CARDS` WRITE;
/*!40000 ALTER TABLE `CARDS` DISABLE KEYS */;
INSERT INTO `CARDS` VALUES (1234567,'2025-01-01',3914),(4567123,'2022-09-21',1000),(5671234,'2022-01-01',1888),(6712345,'2023-01-01',1932),(7123456,'2024-01-01',8124);
/*!40000 ALTER TABLE `CARDS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CREDIT_CARD`
--

DROP TABLE IF EXISTS `CREDIT_CARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CREDIT_CARD` (
  `card_val` bigint  NOT NULL,
  PRIMARY KEY (`card_val`),
  CONSTRAINT `CREDIT_CARD_ibfk_1` FOREIGN KEY (`card_val`) REFERENCES `CARDS` (`card_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CREDIT_CARD`
--

LOCK TABLES `CREDIT_CARD` WRITE;
/*!40000 ALTER TABLE `CREDIT_CARD` DISABLE KEYS */;
INSERT INTO `CREDIT_CARD` VALUES (4567123),(5671234),(7123456);
/*!40000 ALTER TABLE `CREDIT_CARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CUSTOMER`
--

DROP TABLE IF EXISTS `CUSTOMER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CUSTOMER` (
  `ID` bigint  NOT NULL,
  `aadhar_no` bigint  NOT NULL,
  `DOB` date NOT NULL,
  `fname` varchar(30) NOT NULL,
  `mname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `address_line1` varchar(100) NOT NULL,
  `address_line2` varchar(100) NOT NULL,
  `address_line3` varchar(100) NOT NULL,
  `address_line4` varchar(100) NOT NULL,
  `pan_no` bigint  NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `aadhar_no` (`aadhar_no`),
  UNIQUE KEY `pan_no` (`pan_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CUSTOMER`
--

LOCK TABLES `CUSTOMER` WRITE;
/*!40000 ALTER TABLE `CUSTOMER` DISABLE KEYS */;
INSERT INTO `CUSTOMER` VALUES (100,134578942,'2001-01-01','prince','singh','tomar','a','b','c','d',998822),(101,101201301,'1994-12-12','raj','singh','parihar','kl','qt','rt','pa',778811),(102,102202302,'1996-04-28','kate',NULL,'winslet','mt','ab','cd','aq',149213),(103,103203303,'1988-06-14','scarlett',NULL,'johansson','at','ap','rs','wv',421319),(104,104204304,'2001-05-09','virat','runmachine','kohli','yz','qz','za','mn',443391);
/*!40000 ALTER TABLE `CUSTOMER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEBIT_CARD`
--

DROP TABLE IF EXISTS `DEBIT_CARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DEBIT_CARD` (
  `card_val` bigint  NOT NULL,
  PRIMARY KEY (`card_val`),
  CONSTRAINT `DEBIT_CARD_ibfk_1` FOREIGN KEY (`card_val`) REFERENCES `CARDS` (`card_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEBIT_CARD`
--

LOCK TABLES `DEBIT_CARD` WRITE;
/*!40000 ALTER TABLE `DEBIT_CARD` DISABLE KEYS */;
INSERT INTO `DEBIT_CARD` VALUES (1234567),(6712345);
/*!40000 ALTER TABLE `DEBIT_CARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEPENDENT`
--

DROP TABLE IF EXISTS `DEPENDENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DEPENDENT` (
  `ID` bigint  NOT NULL,
  `dependent_fname` varchar(20) NOT NULL,
  `dependent_mname` varchar(20) DEFAULT NULL,
  `dependent_lname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`,`dependent_fname`),
  UNIQUE KEY `dependent_fname` (`dependent_fname`),
  CONSTRAINT `DEPENDENT_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `EMPLOYEE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEPENDENT`
--

LOCK TABLES `DEPENDENT` WRITE;
/*!40000 ALTER TABLE `DEPENDENT` DISABLE KEYS */;
INSERT INTO `DEPENDENT` VALUES (1919,'ab','bc','cd'),(2456,'aab','bac','cad');
/*!40000 ALTER TABLE `DEPENDENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DO`
--

DROP TABLE IF EXISTS `DO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DO` (
  `customer_id` bigint  NOT NULL,
  `payment_id` bigint  NOT NULL,
  `transaction_id` bigint  NOT NULL,
  PRIMARY KEY (`customer_id`,`payment_id`,`transaction_id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `DO_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `Transaction` (`account_no`),
  CONSTRAINT `DO_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`account_no`),
  CONSTRAINT `DO_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `CUSTOMER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DO`
--

LOCK TABLES `DO` WRITE;
/*!40000 ALTER TABLE `DO` DISABLE KEYS */;
INSERT INTO `DO` VALUES (100,112211,112211),(101,491378,491378),(103,341792,341792);
/*!40000 ALTER TABLE `DO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ECONTACT`
--

DROP TABLE IF EXISTS `ECONTACT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ECONTACT` (
  `ID` bigint  NOT NULL,
  `contact_no` bigint  NOT NULL,
  PRIMARY KEY (`ID`,`contact_no`),
  CONSTRAINT `ECONTACT_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `EMPLOYEE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ECONTACT`
--

LOCK TABLES `ECONTACT` WRITE;
/*!40000 ALTER TABLE `ECONTACT` DISABLE KEYS */;
INSERT INTO `ECONTACT` VALUES (1212,2147483647),(1376,2147483647),(1919,2147483647),(2456,1234567890),(9660,2147483647);
/*!40000 ALTER TABLE `ECONTACT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMPLOYEE`
--

DROP TABLE IF EXISTS `EMPLOYEE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMPLOYEE` (
  `ID` bigint  NOT NULL,
  `FNAME` varchar(20) NOT NULL,
  `MINIT` varchar(20) DEFAULT NULL,
  `LNAME` varchar(20) DEFAULT NULL,
  `Super_id` bigint  NOT NULL,
  `DOB` date NOT NULL,
  `post` varchar(30) NOT NULL,
  `salary` bigint  NOT NULL,
  `aadhar_no` bigint  NOT NULL,
  `address_line1` varchar(50) DEFAULT NULL,
  `address_line2` varchar(50) DEFAULT NULL,
  `address_line3` varchar(50) DEFAULT NULL,
  `address_line4` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `aadhar_no` (`aadhar_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
  /* KEY `EMPLOYEE_ibfk_1` (`Super_id`),
  CONSTRAINT `EMPLOYEE_ibfk_1` FOREIGN KEY (`Super_id`) REFERENCES `EMPLOYEE` (`ID`) */
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMPLOYEE`
--

LOCK TABLES `EMPLOYEE` WRITE;
/*!40000 ALTER TABLE `EMPLOYEE` DISABLE KEYS */;
INSERT INTO `EMPLOYEE` VALUES (1212,'Binod',NULL,'kumar',1376,'2001-04-04','cashier',30000,343412388,'i','j','k','l'),(1376,'shreyansh',NULL,'verma',1376,'2000-01-01','supervisor',50000,183427891,'e','f','g','h'),(1919,'rahul',NULL,'kulkarni',1376,'2001-05-09','cashier',25000,432154321,'m','n','o','p'),(2456,'prince','singh','tomar',9660,'2001-01-01','cashier',40000,134578942,'a','b','c','d'),(9660,'manoj',NULL,'sirvi',9660,'2000-11-03','supervisor',60000,482834189,'q','r','s','t');
/*!40000 ALTER TABLE `EMPLOYEE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMPLOYS`
--

DROP TABLE IF EXISTS `EMPLOYS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMPLOYS` (
  `bank_id` bigint  NOT NULL,
  `branch_id` bigint  NOT NULL,
  `employees_id` bigint  NOT NULL,
  PRIMARY KEY (`employees_id`),
  CONSTRAINT `EMPLOYS_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `Bank` (`ID`),
  CONSTRAINT `EMPLOYS_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `BRANCH` (`branch_code`),
  CONSTRAINT `EMPLOYS_ibfk_3` FOREIGN KEY (`employees_id`) REFERENCES `EMPLOYEE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMPLOYS`
--

LOCK TABLES `EMPLOYS` WRITE;
/*!40000 ALTER TABLE `EMPLOYS` DISABLE KEYS */;
INSERT INTO `EMPLOYS` VALUES (11,113498,1376),(42,421392,9660),(42,421392,2456),(11,113498,1212),(11,113498,1919);
/*!40000 ALTER TABLE `EMPLOYS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GOT`
--

DROP TABLE IF EXISTS `GOT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GOT` (
  `customer_id` bigint  NOT NULL,
  `cards_id` bigint  NOT NULL,
  `cheque_id` bigint  NOT NULL,
  `upi_id` bigint  NOT NULL,
  PRIMARY KEY (`cards_id`,`upi_id`,`cheque_id`),
  UNIQUE KEY `cards_id` (`cards_id`),
  UNIQUE KEY `cheque_id` (`cheque_id`),
  UNIQUE KEY `upi_id` (`upi_id`),
  KEY `GOT_ipfk_1` (`customer_id`),
  CONSTRAINT `GOT_ibfk_2` FOREIGN KEY (`cards_id`) REFERENCES `CARDS` (`card_no`),
  CONSTRAINT `GOT_ibfk_3` FOREIGN KEY (`cheque_id`) REFERENCES `cheque` (`cheque_id`),
  CONSTRAINT `GOT_ibfk_4` FOREIGN KEY (`upi_id`) REFERENCES `UPI` (`upi_id`),
  CONSTRAINT `GOT_ipfk_1` FOREIGN KEY (`customer_id`) REFERENCES `CUSTOMER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GOT`
--

LOCK TABLES `GOT` WRITE;
/*!40000 ALTER TABLE `GOT` DISABLE KEYS */;
INSERT INTO `GOT` VALUES (100,1234567,11,11111111),(101,7123456,22,22222222),(102,6712345,33,33333333),(103,5671234,44,44444444),(104,4567123,55,55555555);
/*!40000 ALTER TABLE `GOT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HAS`
--

DROP TABLE IF EXISTS `HAS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HAS` (
  `bank_id` bigint  NOT NULL,
  `atm_id` bigint  NOT NULL,
  `branch_id` bigint  NOT NULL,
  PRIMARY KEY (`bank_id`,`atm_id`,`branch_id`),
  KEY `branch_id` (`branch_id`),
  KEY `HAS_ibfk_3` (`atm_id`),
  CONSTRAINT `HAS_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `Bank` (`ID`),
  CONSTRAINT `HAS_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `BRANCH` (`branch_code`),
  CONSTRAINT `HAS_ibfk_3` FOREIGN KEY (`atm_id`) REFERENCES `ATM` (`atm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HAS`
--

LOCK TABLES `HAS` WRITE;
/*!40000 ALTER TABLE `HAS` DISABLE KEYS */;
INSERT INTO `HAS` VALUES (11,11213,113498),(11,11321,113498),(42,42123,421398),(42,42213,421398);
/*!40000 ALTER TABLE `HAS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOAN`
--

DROP TABLE IF EXISTS `LOAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOAN` (
  `customer_id` bigint  NOT NULL,
  `account_num` bigint  NOT NULL,
  `Date` date NOT NULL,
  `amount` bigint  DEFAULT NULL,
  PRIMARY KEY (`customer_id`,`account_num`,`Date`),
  UNIQUE KEY `customer_id` (`customer_id`),
  KEY `LOAN_ibfk_1` (`account_num`),
  CONSTRAINT `LOAN_ibfk_1` FOREIGN KEY (`account_num`) REFERENCES `ACCOUNT` (`account_no`),
  CONSTRAINT `LOAN_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `CUSTOMER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOAN`
--

LOCK TABLES `LOAN` WRITE;
/*!40000 ALTER TABLE `LOAN` DISABLE KEYS */;
INSERT INTO `LOAN` VALUES (101,491378,'2020-04-25',100000),(103,341792,'2019-02-08',200000),(104,112233,'2019-12-12',300000);
/*!40000 ALTER TABLE `LOAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OFFERS`
--

DROP TABLE IF EXISTS `OFFERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OFFERS` (
  `branch_id` bigint  NOT NULL,
  `Business_banking_id` bigint  NOT NULL,
  `digital_banking_id` bigint  NOT NULL,
  `individual_banking_id` bigint  NOT NULL,
  `Insurance_id` bigint  NOT NULL,
  `Loan_key` bigint  DEFAULT NULL,
  PRIMARY KEY (`Business_banking_id`,`Insurance_id`,`digital_banking_id`,`individual_banking_id`),
  UNIQUE KEY `Business_banking_id` (`Business_banking_id`),
  UNIQUE KEY `digital_banking_id` (`digital_banking_id`),
  UNIQUE KEY `individual_banking_id` (`individual_banking_id`),
  UNIQUE KEY `Insurance_id` (`Insurance_id`),
  UNIQUE KEY `Loan_key` (`Loan_key`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `OFFERS_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `BRANCH` (`branch_code`),
  CONSTRAINT `OFFERS_ibfk_2` FOREIGN KEY (`Business_banking_id`) REFERENCES `Business_banking` (`ID`),
  CONSTRAINT `OFFERS_ibfk_3` FOREIGN KEY (`Insurance_id`) REFERENCES `insurance` (`ID`),
  CONSTRAINT `OFFERS_ibfk_4` FOREIGN KEY (`digital_banking_id`) REFERENCES `digital_banking` (`ID`),
  CONSTRAINT `OFFERS_ibfk_5` FOREIGN KEY (`individual_banking_id`) REFERENCES `individual_banking` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OFFERS`
--

LOCK TABLES `OFFERS` WRITE;
/*!40000 ALTER TABLE `OFFERS` DISABLE KEYS */;
INSERT INTO `OFFERS` VALUES (421392,1,2,3,4,491378),(421392,8,14,19,28,341792),(113498,34,38,9,25,112233);
/*!40000 ALTER TABLE `OFFERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OWNED_by`
--

DROP TABLE IF EXISTS `OWNED_by`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OWNED_by` (
  `account_no` bigint  NOT NULL,
  `customer_no` bigint  NOT NULL,
  PRIMARY KEY (`account_no`,`customer_no`),
  UNIQUE KEY `account_no` (`account_no`),
  UNIQUE KEY `customer_no` (`customer_no`),
  CONSTRAINT `OWNED_by_ibfk_1` FOREIGN KEY (`account_no`) REFERENCES `ACCOUNT` (`account_no`),
  CONSTRAINT `OWNED_by_ibfk_2` FOREIGN KEY (`customer_no`) REFERENCES `CUSTOMER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OWNED_by`
--

LOCK TABLES `OWNED_by` WRITE;
/*!40000 ALTER TABLE `OWNED_by` DISABLE KEYS */;
INSERT INTO `OWNED_by` VALUES (110112,102),(112211,100),(112233,104),(341792,103),(491378,101);
/*!40000 ALTER TABLE `OWNED_by` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Transaction`
--

DROP TABLE IF EXISTS `Transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Transaction` (
  `account_no` bigint  NOT NULL,
  `datetime` datetime NOT NULL,
  `amount` bigint  NOT NULL,
  PRIMARY KEY (`account_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Transaction`
--

LOCK TABLES `Transaction` WRITE;
/*!40000 ALTER TABLE `Transaction` DISABLE KEYS */;
INSERT INTO `Transaction` VALUES (112211,'2020-03-03 12:22:12',10000),(341792,'2020-03-23 10:45:12',20000),(491378,'2019-06-17 04:20:12',30000);
/*!40000 ALTER TABLE `Transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UPI`
--

DROP TABLE IF EXISTS `UPI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UPI` (
  `upi_id` bigint  NOT NULL,
  PRIMARY KEY (`upi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UPI`
--

LOCK TABLES `UPI` WRITE;
/*!40000 ALTER TABLE `UPI` DISABLE KEYS */;
INSERT INTO `UPI` VALUES (11111111),(22222222),(33333333),(44444444),(55555555);
/*!40000 ALTER TABLE `UPI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cheque`
--

DROP TABLE IF EXISTS `cheque`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cheque` (
  `cheque_id` bigint  NOT NULL,
  PRIMARY KEY (`cheque_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cheque`
--

LOCK TABLES `cheque` WRITE;
/*!40000 ALTER TABLE `cheque` DISABLE KEYS */;
INSERT INTO `cheque` VALUES (11),(22),(33),(44),(55);
/*!40000 ALTER TABLE `cheque` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cust_contact`
--

DROP TABLE IF EXISTS `cust_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_contact` (
  `cust_id` bigint  NOT NULL,
  `contact_no` bigint  NOT NULL,
  PRIMARY KEY (`cust_id`,`contact_no`),
  CONSTRAINT `fk_cust_id` FOREIGN KEY (`cust_id`) REFERENCES `CUSTOMER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_contact`
--

LOCK TABLES `cust_contact` WRITE;
/*!40000 ALTER TABLE `cust_contact` DISABLE KEYS */;
INSERT INTO `cust_contact` VALUES (100,1234567890),(101,1111111111),(102,2147483647),(103,2147483647),(104,2147483647);
/*!40000 ALTER TABLE `cust_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `digital_banking`
--

DROP TABLE IF EXISTS `digital_banking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `digital_banking` (
  `ID` bigint  NOT NULL,
  `customer_account_no` bigint  NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `customer_account_no` (`customer_account_no`),
  CONSTRAINT `digital_banking_ibfk_1` FOREIGN KEY (`customer_account_no`) REFERENCES `ACCOUNT` (`account_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `digital_banking`
--

LOCK TABLES `digital_banking` WRITE;
/*!40000 ALTER TABLE `digital_banking` DISABLE KEYS */;
INSERT INTO `digital_banking` VALUES (38,112233),(14,341792),(2,491378);
/*!40000 ALTER TABLE `digital_banking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `individual_banking`
--

DROP TABLE IF EXISTS `individual_banking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `individual_banking` (
  `ID` bigint  NOT NULL,
  `customer_account_no` bigint  NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `customer_account_no` (`customer_account_no`),
  CONSTRAINT `individual_banking_ibfk_1` FOREIGN KEY (`customer_account_no`) REFERENCES `ACCOUNT` (`account_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `individual_banking`
--

LOCK TABLES `individual_banking` WRITE;
/*!40000 ALTER TABLE `individual_banking` DISABLE KEYS */;
INSERT INTO `individual_banking` VALUES (9,112233),(19,341792),(3,491378);
/*!40000 ALTER TABLE `individual_banking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance`
--

DROP TABLE IF EXISTS `insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance` (
  `ID` bigint  NOT NULL,
  `customer_account_no` bigint  NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `customer_account_no` (`customer_account_no`),
  CONSTRAINT `insurance_ibfk_1` FOREIGN KEY (`customer_account_no`) REFERENCES `ACCOUNT` (`account_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance`
--

LOCK TABLES `insurance` WRITE;
/*!40000 ALTER TABLE `insurance` DISABLE KEYS */;
INSERT INTO `insurance` VALUES (25,112233),(28,341792),(4,491378);
/*!40000 ALTER TABLE `insurance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `account_no` bigint  NOT NULL,
  `datetime` datetime NOT NULL,
  `amount` bigint  NOT NULL,
  PRIMARY KEY (`account_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (112211,'2020-03-03 12:22:12',10000),(341792,'2020-03-23 10:45:12',20000),(491378,'2019-06-17 04:20:12',30000);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-03 20:24:21
